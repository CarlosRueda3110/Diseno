package Ejercicioaviones;

public class Appmillas {

	public static void main(String[] args) {

		Piloto piloto1= new Piloto("Luis Fernando Flores Alvarado","Salvadoreño");
		Piloto piloto2= new Piloto("Guillermo Díaz Íbañez","Español");
		Piloto piloto3= new Piloto("Rubén Doblas Gundersen","Noruego");

		Vuelo vuelo1= new Vuelo(112,"Bogota","Miami",1509,piloto1);
		Vuelo vuelo2= new Vuelo(101,"Chicago","Ciudad de Mexico",1721,piloto2);	
		Vuelo vuelo3= new Vuelo(102,"La paz","Buenos Aires",318,piloto3);

		System.out.println("El vuelo " + vuelo1.getNumeroVuelo() + 
	            " que salió de la ciudad " + vuelo1.getCiudadSalida() + 
	            " con destino a " + vuelo1.getCiudadLlegada() + 
	            " del piloto " + vuelo1.getPiloto().getNombre() + 
	            " ha recorrido " + vuelo1.getMillas() + " millas.");	
		System.out.println("El vuelo " + vuelo2.getNumeroVuelo() + 
	            " que salió de la ciudad " + vuelo2.getCiudadSalida() + 
	            " con destino a " + vuelo2.getCiudadLlegada() + 
	            " del piloto " + vuelo2.getPiloto().getNombre() + 
	            " ha recorrido " + vuelo2.getMillas() + " millas.");
		System.out.println("El vuelo " + vuelo3.getNumeroVuelo() + 
	            " que salió de la ciudad " + vuelo3.getCiudadSalida() + 
	            " con destino a " + vuelo3.getCiudadLlegada() + 
	            " del piloto " + vuelo3.getPiloto().getNombre() + 
	            " ha recorrido " + vuelo3.getMillas() + " millas.");
		
		if (vuelo1.getMillas() > vuelo2.getMillas() && vuelo1.getMillas() > vuelo3.getMillas()){
			System.out.println("El vuelo con mas millas recorridas fue el vuelo "+ vuelo1.getNumeroVuelo()+" con un total de "+ vuelo1.getMillas()+" millas.");
		}
		else if (vuelo2.getMillas() > vuelo1.getMillas() && vuelo2.getMillas() > vuelo3.getMillas()){
			System.out.println("El vuelo con mas millas recorridas fue el vuelo "+ vuelo2.getNumeroVuelo()+" con un total de "+ vuelo2.getMillas()+" millas.");
		}	
		else {
			System.out.println("El vuelo con mas millas recorridas fue el vuelo "+ vuelo3.getNumeroVuelo()+" con un total de "+ vuelo3.getMillas()+" millas.");		

		}	


	}

}
