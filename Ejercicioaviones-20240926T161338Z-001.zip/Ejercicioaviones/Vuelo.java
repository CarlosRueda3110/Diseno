package Ejercicioaviones;

public class Vuelo {

	private int numeroVuelo;
	private String ciudadSalida;
	private String ciudadLlegada;
	private int millas;
	private Piloto piloto;
	public int getNumeroVuelo() {
		return numeroVuelo;
	}
	public void setNumeroVuelo(int numeroVuelo) {
		this.numeroVuelo = numeroVuelo;
	}
	public String getCiudadSalida() {
		return ciudadSalida;
	}
	public void setCiudadSalida(String ciudadSalida) {
		this.ciudadSalida = ciudadSalida;
	}
	public String getCiudadLlegada() {
		return ciudadLlegada;
	}
	public void setCiudadLlegada(String ciudadLlegada) {
		this.ciudadLlegada = ciudadLlegada;
	}
	public int getMillas() {
		return millas;
	}
	public void setMillas(int millas) {
		this.millas = millas;
	}
	public Piloto getPiloto() {
		return piloto;
	}
	public void setPiloto(Piloto piloto) {
		this.piloto = piloto;
	}
	public Vuelo(int numeroVuelo, String ciudadSalida, String ciudadLlegada, int millas, Piloto piloto) {
		super();
		this.numeroVuelo = numeroVuelo;
		this.ciudadSalida = ciudadSalida;
		this.ciudadLlegada = ciudadLlegada;
		this.millas = millas;
		this.piloto = piloto;
	}}
	